package actions;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import actions.ListItem.ListItemEntry;
import javafx.collections.ObservableList;
import javafx.scene.Group;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.shape.Line;
import ui.UserInterface.TabNames;

public class ListItem {
	/**********************************************************************************************

	Class Attributes
	
	**********************************************************************************************/
	
	//---------------------------------------------------------------------------------------------
	// These attributes enable us to hide the details of the tab height and the height and width of
	// of the window decorations for the code that implements this user interface
	private int xOffset = 0;
	private int yOffset = 0;
	
	//---------------------------------------------------------------------------------------------
	// The following are the GUI objects that make up the ListItem user interface	
	private String name;
	private String capName;
	private String capNames;
	private Label theTitle;
	private Label theName;
	private String Reg_No = "";
	private String Roll_No = "";
	private String StudentName = "";
	private String FatherName = "";
	private String MotherName = "";
	private String Course = "";
	private String Semester = "";
	private String Year = "";
	
	private TableView <ListItemEntry> theListItemList = new TableView <ListItemEntry>();
	private TableColumn <ListItemEntry, Integer> seqColumn = new TableColumn <>("Seq");
	private TableColumn <ListItemEntry, String> nameColumn;
	public TextField theNameField = new TextField();
	private TextArea theDescriptionArea = new TextArea();
	private Button btnEdit = new Button("Edit \u21e8");
	private Button btnSave = new Button("\u21e6 Save");
	private Button btnAddBottom = new Button("\u21b2 Add");
	private Button btnAddUp = new Button("\u2196 Add");
	private Button btnAddDn = new Button("\u2199 Add");
	private Button btnMoveUp = new Button("Move Up");
	private Button btnMoveDn = new Button("Move Dn");
	private Button btnDelete = new Button("Delete");
	private Button btnClear = new Button("Clear the above Name and Description");
	
	
	// Change and saved lines
	private Label changeMessage = new Label("Content has changed and has not been saved!");
	private Line line = new Line(); 
	private Line line2 = new Line(); 
	private Line line3 = new Line();
	private String t_Name = ""; //Store name of table 
	Connection myConn = null; // Establish a connection
	

	//---------------------------------------------------------------------------------------------
	// The following is used to simplify those cases where there are tab specific data
	protected int tabSpecificIndex = -1;
	
	/**********
	 * This ListItem constructor places each of the GUI elements into a group that can be shown when
	 * the tab is activated and hidden when leaving the tab.
	 * 
	 * @param g		This is the group that is used for the specific Tab
	 * @param x		This is the x axis offset and the
	 * @param y		y axis offset to be used to hide the details of the context from this code
	 */
	public ListItem(Group g, int x, int y, TabNames t) {
		// Save the offset values
		xOffset = x;
		yOffset = y;
		
		// Save the item name
		switch (t) {
		case STUDENT_REGISTRATION: 
			name = "Student Registration";
			capName = "Student Registration";
			capNames = "Student Registration";
			t_Name = "Student Registration";
			setupChangeMessage(340, 520, 970);

			break;
		}
		//The code below establishes the connectivity of the code with MySql database
				//and retrieve the data from MySql tables and show it on UI
				try{
					Class.forName("com.mysql.cj.jdbc.Driver");
					myConn = DriverManager.getConnection("jdbc:mysql://localhost:3306/PETSDB","root","195357195");
					Statement st = myConn.createStatement();
					ResultSet myRes = st.executeQuery("select * from " + t_Name);
					
					switch(t_Name) {
					case "artifacts":
					while(myRes.next()) {
						System.out.println(myRes.getString("artifact_name")+" "+myRes.getString("artifact_desc"));
						ObservableList<ListItemEntry> de = theListItemList.getItems();
						int theItemIndex = de.size();
						ListItemEntry def = new ListItemEntry(theItemIndex+1,myRes.getString("artifact_name") ,myRes.getString("artifact_desc"));
						// Add the new item entry at the end of the list
						de.add(def);
						
						// Place the list into the TableView
						theListItemList.setItems(de);
						
					}
		
	}
}
